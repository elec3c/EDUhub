<?php

return [
    'modExtraUserPolicyTemplate' => [
        'description' => 'modExtra policy template description.',
        'template_group' => 1,
        'permissions' => [
            'modextra_save' => [],
        ]
    ],
];