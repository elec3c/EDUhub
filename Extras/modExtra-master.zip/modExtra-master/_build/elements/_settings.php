<?php

return [
    'some_setting' => [
        'xtype' => 'combo-boolean',
        'value' => true,
        'area' => 'modextra_main',
    ],
];