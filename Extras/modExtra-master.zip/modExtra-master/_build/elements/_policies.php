<?php

return [
    'modExtraUserPolicy' => [
        'description' => 'modExtra policy description.',
        'data' => [
            'modextra_save' => true,
        ]
    ],
];