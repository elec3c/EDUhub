<?php

return [
    'tpl.modExtra.item' => [
        'file' => 'item',
        'description' => '',
    ],
    'tpl.modExtra.office' => [
        'file' => 'office',
        'description' => '',
    ],
];