<?php
require_once (dirname(__DIR__) . '/modextraitem.class.php');
class modExtraItem_mysql extends modExtraItem {}